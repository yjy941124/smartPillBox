# smartPillBox
This is smart pillbox by ICSL. Author: Jinyang Yu
This app is implemented by node.js and hosted on AWS ElasticBeanStalk.
TODO: Implement upload record and sync schedule
